﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Morozova_Krasota
{
    /// <summary>
    /// Логика взаимодействия для Prise.xaml
    /// </summary>
    public partial class Prise : Window
    {
        public Prise()
        {
            InitializeComponent();
        }

        private void BTN_back_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            Close();
            mainWindow.Show();
            
        }

        private void BTN_ivite_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Приложение в стадии разработки", "Уведомление",
                    MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}
