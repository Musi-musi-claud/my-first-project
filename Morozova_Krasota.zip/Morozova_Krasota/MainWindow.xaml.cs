﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Morozova_Krasota
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BTN_prise_Click(object sender, RoutedEventArgs e)
        {
            Prise prise = new Prise();
            Close();
            prise.ShowDialog();
        }

        private void BTN_invite_bode_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Приложение в стадии разработки", "Уведомление",
                    MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void BTN_invite_head_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Приложение в стадии разработки", "Уведомление",
                    MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}